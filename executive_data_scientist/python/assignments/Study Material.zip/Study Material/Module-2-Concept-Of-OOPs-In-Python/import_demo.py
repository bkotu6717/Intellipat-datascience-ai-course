import module as md

print("md.addition(2,3): ", md.addition(2,3))
print("md.substraction(2,3): ", md.substraction(2,3))
print("md.multiplication(2,3): ", md.multiplication(2,3))
print("md.division(2,3): ", md.division(2,3))
