# Problem Statement:
# You work in XYZ Corporation as a Data Analyst. Your company has told you to
# work with the looping statements.

# Tasks To Be Performed:
# 1. Print the numbers from 1 to 10 using while loop.

i = 1
while (i <= 10):
	print(i)
	i += 1